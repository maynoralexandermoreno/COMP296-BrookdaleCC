/*
 * Unused Class; Kept as launching off point for future iterations of program
 */

//package holderObjects;
//
//public class PhoneNumber {
///**
// * contains phone_number_id
// */
//	private int phone_number_id;
///**
// * contains customer_id
// */
//	private int customer_id;
///**
// * contains phone_number
// */
//	private String phone_number;
///**
// * contains description
// */
//	private String description;
//
///**
// * CONSTRUCTOR
// * 
// * @param n_id			int phone_number_id
// * @param c_id			int customer_id
// * @param num			String phone_number
// * @param descr			String description
// */
//	public PhoneNumber(int n_id, int c_id, String num, String descr) {
//		this.phone_number_id = n_id;
//		this.customer_id = c_id;
//		this.phone_number = num;
//		this.description = descr;
//	}
//
///**
// * getter  method
// * @return phone_number_id
// */
//	public int getPhoneNumberId() {
//		return this.phone_number_id;
//	}
///**
// * getter method
// * @return customer_id
// */
//	public int getCustomerId() {
//		return this.customer_id;
//	}
///**
// * getter method
// * @return phone_number
// */
//	public String getPhoneNumber(){
//		return this.phone_number;
//	}
///**
// * getter method
// * @return description
// */
//	public String getDescription() {
//		return this.description;
//	}
//}
