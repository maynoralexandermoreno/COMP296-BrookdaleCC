/*
 * Class not used; kept as launching off point for future iterations of program
 */

//package holderObjects;
//
//public class Address {
//	private int address_id;
//
//	private int customer_id;
//
//	private String address_1;
//
//	private String address_2;
//
//	private String city;
//
//	private String state;
//
//	private String zip_code;
//
//	public Address(int a_id, int c_id, String add_1, String add_2, String town, String st, String zip) {
//		this.address_id = a_id;
//		this.customer_id = c_id;
//		this.address_1 = add_1;
//		this.address_2 = add_2;
//		this.city = town;
//		this.state = st;
//		this.zip_code = zip;
//	}
//
//
//	public int getAddressId() {
//		return this.address_id;
//	}
//
//	public int getCustomerId() {
//		return this.customer_id;
//	}
//
//	public String getAddress1() {
//		return this.address_1;
//	}
//
//	public String getAddress2() {
//		return this.address_2;
//	}
//	public String getCity() {
//		return this.city;
//	}
//
//	public String getState() {
//		return this.state;
//	}
//
//	public String getZipCode() {
//		return this.zip_code;
//	}
//	
//	public String toString() {
//		String s = this.address_1 + " " + this.address_2 + " " + this.city + " " + this.state + " " + this.zip_code;
//		return s;
//	}
//}
